import java.util.Scanner;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class UserGreeting {
    
    // Using Scanner class
    public static void greetWithScanner() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();
        
        System.out.println("Hello " + name + "! You are " + age + " years old.");
        
        scanner.close();
    }
    
    // Using NIO classes
    public static void greetWithNIO() {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in, StandardCharsets.UTF_8))) {
            
            System.out.print("Enter your name: ");
            String name = reader.readLine();
            
            System.out.print("Enter your age: ");
            int age = Integer.parseInt(reader.readLine());
            
            System.out.println("Hello " + name + "! You are " + age + " years old.");
            
        } catch (IOException e) {
            System.err.println("Error reading input: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Invalid age format. Please enter a valid number.");
        }
    }
    
    public static void main(String[] args) {
        System.out.println("=== Using Scanner ===");
        greetWithScanner();
        
        System.out.println("\n=== Using NIO ===");
        greetWithNIO();
    }
}