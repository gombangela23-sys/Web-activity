public class Rectangle {
    // Fields
    private double length;
    private double width;
    
    // Constructor
    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }
    
    // Getter and Setter methods
    public double getLength() {
        return length;
    }
    
    public void setLength(double length) {
        this.length = length;
    }
    
    public double getWidth() {
        return width;
    }
    
    public void setWidth(double width) {
        this.width = width;
    }
    
    // Method to calculate area
    public double calculateArea() {
        return length * width;
    }
    
    // Method to calculate perimeter
    public double calculatePerimeter() {
        return 2 * (length + width);
    }
    
    // Method to display rectangle information
    public void displayInfo() {
        System.out.println("Rectangle: " + length + " x " + width);
        System.out.println("Area: " + calculateArea());
        System.out.println("Perimeter: " + calculatePerimeter());
    }
    
    // Main method to demonstrate the class
    public static void main(String[] args) {
        // Create Rectangle objects
        Rectangle rect1 = new Rectangle(5.0, 3.0);
        Rectangle rect2 = new Rectangle(7.5, 4.2);
        
        // Use the objects
        System.out.println("=== Rectangle 1 ===");
        rect1.displayInfo();
        
        System.out.println("\n=== Rectangle 2 ===");
        rect2.displayInfo();
        
        // Calculate area directly
        System.out.println("\nDirect area calculation:");
        System.out.println("Rectangle 1 area: " + rect1.calculateArea());
        System.out.println("Rectangle 2 area: " + rect2.calculateArea());
        
        // Modify and recalculate
        rect1.setLength(6.0);
        rect1.setWidth(4.0);
        System.out.println("\n=== After modification ===");
        rect1.displayInfo();
    }
}